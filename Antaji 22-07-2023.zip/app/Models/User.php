<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $primaryKey = 'uuid';
    public $incrementing = false;
        protected $appends = ['image', 'cover_user', 'video_user', 'city_name', 'country_name', 'products_count', 'reviews', 'response', 'specialization_name', 'commission'];
    protected $fillable = [
        'name',
        'email',
        'city_uuid',
        'country_uuid',
        'mobile',
        'type',
        'password',
        'specialization_uuid',
        'brief',
        'lat',
        'lng',
        'address',
        'package_uuid'
    ];
    const USER = "user";
    const ARTIST = "artist";
    const PATH_COVER = "/upload/user/cover/";
    const PATH_PERSONAL = "/upload/user/personal/";
    const PATH_VIDEO = "/upload/user/video/";
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'country_uuid',
        'city_uuid',
        'city',
        'country',
        'coverImage',
        'videoImage',
        'imageUser'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    /**
     * Relations
     */
    public function country()
    {
        return $this->belongsTo(Country::class, 'country_uuid');
    }
    public function package()
    {
        return $this->belongsTo(Package::class, 'package_uuid');
    }
    public function specialization()
    {
        return @$this->belongsTo(Specialization::class, 'specialization_uuid');
    }

    public function city()
    {
        return $this->belongsTo(City::class, 'city_uuid');
    }

    public function fcm_tokens()
    {
        return $this->hasMany(FcmToken::class, 'user_uuid');
    }

    public function coverImage()
    {
        return $this->morphOne(Upload::class, 'imageable')->where('type', '=', Upload::IMAGE)->where('name', '=', 'cover_photo');
    }

    public function videoImage()
    {
        return $this->morphOne(Upload::class, 'imageable')->where('type', '=', Upload::VIDEO);
    }

    public function imageUser()
    {
        return $this->morphOne(Upload::class, 'imageable')->where('type', '=', Upload::IMAGE)->where('name', '=', 'personal_photo');
    }

    public function skills()
    {
        return $this->belongsToMany(Skill::class, 'skill_user', 'user_uuid', 'skill_uuid');
    }

    public function products()
    {
        return $this->hasMany(Product::class, 'user_uuid');
    }
    public function favorite()
    {
        return $this->hasMany(FavoriteUser::class, 'reference_uuid');
    }
//    public function deliveryAddresses()
//    {
//        return $this->hasMany(DeliveryAddresses::class, 'user_uuid')->where('default',1);
//    }
    /**
     * Attribute
     */

    public function getCountryNameAttribute()
    {
        return @$this->country->name;
    }

    public function getCityNameAttribute()
    {
        return @$this->city->name;
    }

    public function getSpecializationNameAttribute()
    {
        return @$this->specialization->name;
    }

    public function getCoverUserAttribute()
    {
        return (@$this->coverImage->filename) ? url('/') . self::PATH_COVER . @$this->coverImage->filename : null;
    }

    public function getVideoUserAttribute()
    {
        return (@$this->videoImage->filename) ? url('/') . self::PATH_VIDEO . @$this->videoImage->filename : null;
    }

    public function getImageAttribute()
    {
        if (@$this->imageUser->filename) {
            return url('/') . self::PATH_PERSONAL . @$this->imageUser->filename;
        } else {
            return url('/') . '/upload/user/fea062c5fb579ac0dc5ae2c22c6c51fb.jpg';

        }
    }

    public function getLatAttribute($value)
    {
        return latLngFormat($value);
    }

    public function getLngAttribute($value)
    {
        return latLngFormat($value);
    }

    public function getProductsCountAttribute()
    {
        return $this->products->count();
    }

    public function getResponseAttribute()
    {
        return '3 ' . __('hours');
    }

    public function getReviewsAttribute()
    {
        return number_format(100, 1, '.', '') . '%';
    }
    public function message(){
        return $this->hasMany(Message::class,'user_uuid');
    }
    public function getCommissionAttribute()
    {
        return $this->package->percentage_of_sale / 100;
    }

    /**
     * Boot
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($item) {
            $item->uuid = Str::uuid();
        });
        static::addGlobalScope('user', function (Builder $builder) {
            $builder->where('status', 1);//1==active
        });

    }
}
