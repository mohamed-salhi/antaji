<?php

namespace App\Http\Controllers\Admin\Support;

use App\Http\Controllers\Controller;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    public function messags($uuid=null){
        $user=User::query()->has('message')->orderByDesc('created_at')->get();

        if($uuid){
            $msg=User::query()->where('uuid',$uuid)->with('message')->orderByDesc('created_at')->first();
        }else{
            $msg=User::query()->has('message')->with('message')->orderByDesc('created_at')->first();
        }
        return view('admin.support.messags',compact('user','msg'));
    }

    public function message(Request $request){
        $rules = [
            'message' => 'required|max:100',
            'user_uuid' => 'required|',
        ];
        $this->validate($request, $rules);

        $request->merge([
            'status'=>'admin'
        ]);
        $msg=   Message::create($request->only('message','user_uuid','status'));
        event (new \App\Events\Msg($request->message,$request->user_uuid,"admin",$request->user_uuid,'ds'));
        return $this->sendResponse(null, __('item_edited'));

    }
}
